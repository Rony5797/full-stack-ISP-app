import PackageCart from "./mincomp/PackageCart";
import "./css/packages-page.css";
const AllPackagesPage = () => {
  return (
    <section className="packages-page">
      <PackageCart
        Img="img/pricing-1.jpg"
        level="Bronze Package"
        price="1000"
        mb="30"
      />
      <PackageCart
        Img="img/pricing-1.jpg"
        level="Bronze Package"
        price="1000"
        mb="30"
      />
      <PackageCart
        Img="img/pricing-1.jpg"
        level="Bronze Package"
        price="1000"
        mb="30"
      />
      <PackageCart
        Img="img/pricing-1.jpg"
        level="Bronze Package"
        price="1000"
        mb="30"
      />
      <PackageCart
        Img="img/pricing-1.jpg"
        level="Bronze Package"
        price="1000"
        mb="30"
      />
      <PackageCart
        Img="img/pricing-1.jpg"
        level="Bronze Package"
        price="1000"
        mb="30"
      />
      <PackageCart
        Img="img/pricing-1.jpg"
        level="Bronze Package"
        price="1000"
        mb="30"
      />
      <PackageCart
        Img="img/pricing-1.jpg"
        level="Bronze Package"
        price="1000"
        mb="30"
      />
      <PackageCart
        Img="img/pricing-1.jpg"
        level="Bronze Package"
        price="1000"
        mb="30"
      />
    </section>
  );
};

export default AllPackagesPage;
