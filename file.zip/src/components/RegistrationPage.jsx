const RegistrationPage = () => {
  return <div>RegistrationPage</div>;
};

export default RegistrationPage;
