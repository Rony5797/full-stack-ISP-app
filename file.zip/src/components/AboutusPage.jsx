const AboutusPage = () => {
  return <div>AboutusPage</div>;
};

export default AboutusPage;
